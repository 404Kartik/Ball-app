import React, { useEffect, useState } from "react";
import Cookies from "js-cookie";
import "./App.css";

const App = () => {
  const [ballColor, setBallColor] = useState("");
  const [redCount, setRedCount] = useState(0);
  const [blueCount, setBlueCount] = useState(0);

  useEffect(() => {
    let storedBallColor = Cookies.get("ballColor");
    let storedRedCount = parseInt(Cookies.get("redCount") || "0", 10);
    let storedBlueCount = parseInt(Cookies.get("blueCount") || "0", 10);
    if (!storedBallColor) {
      storedBallColor = Math.random() < 0.5 ? "red" : "blue";
      Cookies.set("ballColor", storedBallColor);
    }
    if (storedBallColor === "red") {
      storedRedCount++;
      Cookies.set("redCount", storedRedCount);
    } else {
      storedBlueCount++;
      Cookies.set("blueCount", storedBlueCount);
    }
    setBallColor(storedBallColor);
    setRedCount(storedRedCount);
    setBlueCount(storedBlueCount);
  }, []);

  return (
    <div id="container">
      <div id="container-data">
        {" "}
        <h2 id="ball-image">
          {ballColor === "red" ? "🔴" : "🔵"}{" "}
          {`${ballColor} ball`}
        </h2>
        <div id="report">
          <p id="red-count">Red ball seen: {redCount} times</p>
          <p id="blue-count">Blue ball seen: {blueCount} times</p>
        </div>
      </div>
    </div>
  );
};

export default App;
